#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){
    sound.loadSound("beat.wav"); //Loads a sound file (in bin/data/)
    sound.setLoop(true); // Makes the song loop indefinitely
    sound.setVolume(1); // Sets the song volume
    ofSetBackgroundColor(36, 32,56); // Sets the Background Color
}

//--------------------------------------------------------------
void ofApp::update(){
    /* The update method is called muliple times per second
    It's in charge of updating variables and the logic of our app */
    ofSoundUpdate(); // Updates all sound players
    visualizer.updateAmplitudes(); // Updates Amplitudes for visualizer
    if(repl && !record){
    if (counter%180==0 && iter<t.size()){
        keys=true;
        keyPressed((t[iter]));
        iter++;
    } else if (iter>=t.size()){
        repl=false;
    }
    counter++;
    }
}

//--------------------------------------------------------------
void ofApp::draw(){
    /* The update method is called muliple times per second
    It's in charge of drawing all figures and text on screen */
    if(!playing){
        ofDrawBitmapString("Press 'p' to play some music!", ofGetWidth()/2 - 50, ofGetHeight()/2);
    }
    vector<float> amplitudes = visualizer.getAmplitudes();
    if(mode == '1'){
        drawMode1(amplitudes);
    }else if(mode == '2'){
        drawMode2(amplitudes);
    }else if(mode == '3'){
        drawMode3(amplitudes);
    }

    if (record){
		ofDrawBitmapString("Recording!", 700, 20);
	}
	if (repl){
		ofDrawBitmapString("Replaying!", 700, 20);
	}
}
void ofApp::drawMode1(vector<float> amplitudes){
        ofBackgroundGradient(ofColor(200,20,255), ofColor(200,20,255));
        ofFill(); // Drawn Shapes will be filled in with color
        ofSetColor(256); // This resets the color of the "brush" to white
        ofDrawBitmapString("Rectangle Height Visualizer", 0, 15);
        ofSetColor(x, y, z);
        for (int i=0; i<64; i++) {
        ofDrawRectangle(2+(i*wide), ofGetHeight() - 100, wide,  amplitudes[i]);
        }
        ofDrawBitmapString("Volume:" + ofToString(sound.getVolume()), 5, 60);
}
void ofApp::drawMode2(vector<float> amplitudes){
        ofBackgroundGradient(ofColor(102, 255, 51), ofColor(102, 255, 51));
        ofSetLineWidth(5); // Sets the line width
        ofNoFill(); // Only the outline of shapes will be drawn
        ofSetColor(256); // This resets the color of the "brush" to white
        ofDrawBitmapString("Circle Radius Visualizer", 0, 15);
        int bands = amplitudes.size();
        for(int i=0; i< bands; i++){
            ofSetColor((bands - i)*32 %256,18,144); // Color varies between frequencies
            ofDrawCircle(ofGetWidth()/2, ofGetHeight()/2, amplitudes[0]/(i +1));
        }
        ofDrawBitmapString("Volume:" + ofToString(sound.getVolume()), 5, 60);
}

void ofApp::drawMode3(vector<float> amplitudes){
    ofBackgroundGradient(ofColor(0,0,255), ofColor(0,0,255));
    ofSetColor(256); // This resets the color of the "brush" to white
    ofDrawBitmapString("Rectangle Width Visualizer", 0, 15);
    ofSetColor(x, y, z);
    for (int i=0; i<64; i++) {
        ofDrawRectangle(ofGetWidth(), 2+(i*tall), amplitudes[i], tall);
        }
    ofDrawBitmapString("Volume:" + ofToString(sound.getVolume()), 5, 60);

}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){
    // This method is called automatically when any key is pressed
    if (key=='c'){
        repl=false;
    }
    if (repl && !keys){
                return;
            } keys=false;
    if(record && key!='r'){
        t.push_back(key);
    }
    switch(key){
        case 'p':
            if(playing){
                sound.stop();
            }else{
                sound.play();
            }
            playing = !playing;
            break;
        case '1':
            mode = '1';
            x=ofRandom(261);
		    y=ofRandom(261);
		    z=ofRandom(261);
            break;
        case '2':
            mode = '2';
            break;
        case '3':
            mode = '3';
            x=ofRandom(261);
		    y=ofRandom(261);
		    z=ofRandom(261);
            break;
        case 'a':
            if(playing){
                sound.setPaused(true);
                visualizer.pause = true;
            }else {
                sound.setPaused(false);
                visualizer.pause = false;
            }
            playing = !playing;
            break;
        case 'd':
            if (playing){
                sound.loadSound("geesebeat.wav");
                sound.setLoop(true);
                sound.play();
            }else {
                sound.loadSound("geesebeat.wav");
                sound.setLoop(true); 
            }
            break;
        case 'f':
            if (playing){
                sound.loadSound("pigeon-coo.wav");
                sound.setLoop(true);
                sound.play();
            }else {
                sound.loadSound("pigeon-coo.wav");
                sound.setLoop(true); 
            }
            break;
        case 'g':
            if (playing){
                sound.loadSound("rock-song.wav");
                sound.setLoop(true);
                sound.play();
            }else {
                sound.loadSound("rock-song.wav");
                sound.setLoop(true); 
            }
            break;
        case 'h':
            if (playing){
                sound.loadSound("beat.wav");
                sound.setLoop(true);
                sound.play();
            }else {
                sound.loadSound("beat.wav");
                sound.setLoop(true); 
            }
            break;
        case '-':
            if (sound.getVolume()!=0){
            sound.setVolume(sound.getVolume()-0.1);
            }   
             if (sound.getVolume() < 0){
                sound.setVolume(0);
            }
            break;
        case '=':
            if (sound.getVolume()!=1){
            sound.setVolume(sound.getVolume()+0.1);
            }
            if (sound.getVolume() > 1){
                sound.setVolume(1);
            }
            break;
        case 'r':
            record = !record;
            break;
        case 't':
           repl=true;
           break;
            
    }
}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 

}