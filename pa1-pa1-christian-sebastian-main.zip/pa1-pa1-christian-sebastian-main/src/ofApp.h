#pragma once

#include "ofMain.h"
#include "AudioVisualizer.h"
#include <string>

class ofApp : public ofBaseApp{
	public:
		void setup();
		void update();
		void draw();

		void drawMode1(vector<float> amplitudes);
		void drawMode2(vector<float> amplitudes);
		void drawMode3(vector<float> amplitudes);
		void keyPressed(int key);
		void keyReleased(int key);
		void mouseMoved(int x, int y);
		void mouseDragged(int x, int y, int button);
		void mousePressed(int x, int y, int button);
		void mouseReleased(int x, int y, int button);
		void mouseEntered(int x, int y);
		void mouseExited(int x, int y);
		void windowResized(int w, int h);
		void dragEvent(ofDragInfo dragInfo);
		void gotMessage(ofMessage msg);
		void replay (vector<int> t, int size);
	private:
		ofSoundPlayer sound;
		AudioVisualizer visualizer;
		
		bool playing = false;
		char mode = '1';
		double x=ofRandom(261);
		double y=ofRandom(261);
		double z=ofRandom(261);
		double tall=ofGetHeight()/64;
		double wide=ofGetWidth()/64;
		bool record = false;
		bool repl = false;
		bool cancel = false;
		bool keys = false;
		vector<int> t;
		int time;
		int counter;
		int iter;
};
